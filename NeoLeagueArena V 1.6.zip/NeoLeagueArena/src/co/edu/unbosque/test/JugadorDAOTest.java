package co.edu.unbosque.test;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;



public class JugadorDAOTest {

	@BeforeClass
	public static void hacerAntesdelaspruevas() {

	}

	@Before
	public void hcerAntesDeCadaPrueba() {

	}

	@Test
	public void verificarConvercionEntidadDTO() {

	}

	@Test
	public void verificarConversionDTOEntidad() {

	}

	@Test
	public void verificarConstructor() {

	}

	@After
	public void hacerDespuesDeCadaPrueba() {

	}

	@AfterClass
	public static void hacerDespuesDeTodo() {

	}

}
