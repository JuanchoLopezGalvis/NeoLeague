package co.edu.unbosque.view;

import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;

public class VentanaEntrenador extends JFrame{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JMenuBar menuBar;
//	private JMenu gestionarEquipos, gestionarCuenta, ;
	
	public VentanaEntrenador() {
		setSize(1280,720);
		setLocationRelativeTo(null);
		setResizable(false);
	}
	
}
