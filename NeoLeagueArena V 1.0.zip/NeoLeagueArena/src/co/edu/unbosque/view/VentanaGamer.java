package co.edu.unbosque.view;

import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;

public class VentanaGamer extends JFrame{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JMenuBar menuBar;
	private JMenu menuBar2;
	
	
	public VentanaGamer() {
		setSize(1280,720);
		setLocationRelativeTo(null);
		setResizable(false);
	}

}
