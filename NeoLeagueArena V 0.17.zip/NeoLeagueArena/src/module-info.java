/**
 * 
 */
/**
 * 
 */
module NeoLeagueArena {
	requires java.desktop;
}