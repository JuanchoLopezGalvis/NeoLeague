package co.edu.unbosque.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import javax.swing.JComboBox;
import javax.swing.JSpinner;
import javax.swing.SpinnerNumberModel;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import co.edu.unbosque.view.CrearAdmin;

public class CrearAdminTest {

    static CrearAdmin panel;

    @BeforeClass
    public static void hacerAntesdelaspruevas() {
        System.out.println("Iniciando las pruebas unitarias de CrearAdmin");
        panel = new CrearAdmin();
    }

    @Before
    public void hcerAntesDeCadaPrueba() {
        System.out.println("Ejecutando prueba");
    }

    @Test
    public void testComponentesNoNulos() {
        assertNotNull(panel.getDatoNombre());
        assertNotNull(panel.getDatoContrasena());
        assertNotNull(panel.getDatoContrasenaConf());
        assertNotNull(panel.getDatoCorreo());
        assertNotNull(panel.getDatoEdad());
        assertNotNull(panel.getDatoPais());
        assertNotNull(panel.getPasswordAdmins());
        assertNotNull(panel.getDatoCargoEspecifico());
        assertNotNull(panel.getSeleccionarFoto());
        assertNotNull(panel.getBotonCrearAdmin());
        assertNotNull(panel.getVerContrasena());
        assertNotNull(panel.getVerContrasenaAdmins());
    }

    @Test
    public void testSpinnerEdadConfigurado() {
        JSpinner spinner = panel.getDatoEdad();
        SpinnerNumberModel model = (SpinnerNumberModel) spinner.getModel();
        assertEquals(0, model.getMinimum());
        assertTrue((Integer) model.getStepSize() > 0);
    }

    @Test
    public void testComboBoxPaisTieneElementos() {
        JComboBox<String> comboBox = panel.getDatoPais();
        assertTrue(comboBox.getItemCount() > 1);
    }

    @Test
    public void testContrasenasOcultasPorDefecto() {
        assertEquals('●', panel.getDatoContrasena().getEchoChar());
        assertEquals('●', panel.getDatoContrasenaConf().getEchoChar());
        assertEquals('●', panel.getPasswordAdmins().getEchoChar());
    }

    @After
    public void hacerDespuesDeCadaPrueba() {
        System.out.println("Prueba finalizada");
    }

    @AfterClass
    public static void hacerDespuesDeTodo() {
        System.out.println("Todas las pruebas de CrearAdmin han finalizado");
        panel = null;
    }

}
