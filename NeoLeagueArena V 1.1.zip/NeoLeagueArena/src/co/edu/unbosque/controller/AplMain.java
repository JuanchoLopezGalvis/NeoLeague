package co.edu.unbosque.controller;
/**
 * * La clase {@link AplMain} es la clase principal de la aplicacion.
 * Contiene el metodo main que se encarga de inicializar la aplicacion.
 */
public class AplMain {
	/**
	 * Este es el metodo main que se encarga de inicializar la aplicacion.
	 * @param args
	 */
	public static void main(String[] args) {
		Controller controller = new Controller();
		controller.run();
	}
}