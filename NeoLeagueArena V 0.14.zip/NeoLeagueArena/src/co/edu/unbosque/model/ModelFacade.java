package co.edu.unbosque.model;

public class ModelFacade {

}
