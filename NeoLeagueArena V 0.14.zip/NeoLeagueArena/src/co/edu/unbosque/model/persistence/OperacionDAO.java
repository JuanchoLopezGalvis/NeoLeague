package co.edu.unbosque.model.persistence;

public interface OperacionDAO {

}
