package co.edu.unbosque.model.persistence;

public class DataMapper {

}
